# Overleaf package — Smart Agriculture: Deep Transfer Learning Frameworks for High-Accuracy Cotton Crop Disease Classification

Frontiers submission package converted from the Word draft
(`v1_Dr_Wazir_Send_File_Dr_Mudasar_30_08_2026_Smart_Agriculture.docx`).

## Uploading to Overleaf

1. Go to Overleaf → **New Project → Upload Project** and drop in
   `Cotton_Frontiers_Overleaf.zip`.
2. Open **Menu** (top left) and set:
   - **Compiler:** `pdfLaTeX`
   - **Main document:** `main.tex`
3. Press **Recompile** twice so the bibliography and cross-references resolve.

That is all — no other configuration is needed.

## What is in the package

| File | Purpose |
|---|---|
| `main.tex` | The manuscript. |
| `references.bib` | All 53 references as BibTeX entries. |
| `figures/` | 35 PNG files extracted at original resolution from the Word file. |
| `FrontiersinVancouver.cls` | Class file — numbered (Vancouver) reference style. |
| `FrontiersinHarvard.cls` | Class file — author–date (Harvard) style, if the target journal needs it. |
| `frontiersinFPHY_FAMS.cls` | Class file for Frontiers in Physics / Applied Maths & Statistics. |
| `Frontiers-Vancouver.bst`, `Frontiers-Harvard.bst` | Matching bibliography styles. |
| `logo1.eps`, `logo1-eps-converted-to.pdf` | Required by the class to build the first-page header. Do not delete. |
| `logo2.*`, `logos.*` | Supplied by Frontiers; unused but kept for completeness. |
| `main.pdf` | Reference build (34 pages), so you can see the expected output. |

## Reference style

The draft uses numbered citations, so the package is set up for the **Vancouver**
style. If the target Frontiers journal uses author–date instead, change two lines
in `main.tex`:

```latex
\documentclass[utf8]{FrontiersinHarvard}   % line 20
\bibliographystyle{Frontiers-Harvard}      % near the end
```

## Figure mapping

Figures were exported from the Word file and renamed. Figures 10–13 were single
stacked blocks in Word; they are split here across continued floats so nothing
overflows the page, but the numbering the reader sees is unchanged.

| Figure | Files |
|---|---|
| 1–9 | `fig01_efficientnetb0` … `fig09_framework` |
| 10 (a–j) | `fig10a_vgg16` … `fig10j_efficientnetb0` |
| 11 | `fig11a_cm` … `fig11e_cm` |
| 12 | `fig12a_qual` … `fig12e_qual` |
| 13 | `fig13a_mis` … `fig13e_mis` |
| 14 | `fig14_complexity` |

## Before you submit

Placeholders that still need real values:

- **Corresponding author email** — `corresponding.author@buetk.edu.pk` in `main.tex`.
- **Author Contributions** — a draft statement is provided; confirm it matches
  what each author actually did.
- **Funding** — currently states that no specific funding was received.
- **Acknowledgments** — left empty.
- **Data Availability Statement** — add the direct Mendeley Data DOI/link.
- **Affiliations** — Frontiers asks for city and country; currently
  "Khuzdar, Pakistan". Add department/laboratory detail if required.

Frontiers also asks that figures be uploaded as separate files at submission.
They are already individual PNGs in `figures/`, so they can be uploaded directly.
